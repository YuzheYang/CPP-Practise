#include <iostream>
using namespace std;
int main()
{
    cout << "Hello, world!" << endl;
    cout << "This is another code for finding jobs" << endl;
    return 0;
}